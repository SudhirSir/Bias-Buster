const GROQ_API_KEY = 'GROQ_API_KEY_PLACEHOLDER';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_MODEL = 'llama3-70b-8192';

chrome.runtime.onMessage.addListener((req, _s, send)=>{
  if(req.action==='ping'){send({pong:true}); return true;}
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('Bias Buster extension installed');
  chrome.storage.local.set({
    enabled: true,
    highlightBias: true,
    showNeutralRewrites: true,
    showBiasScore: true,
    showSummary: true,
    showFactChecking: true
  });
});

chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      const action = command === 'toggle_bias_buster' ? 'toggleBiasBuster' : 'openCustomTextAnalyzer';
      chrome.tabs.sendMessage(tabs[0].id, { action });
    }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'analyzeText':
      analyzeText(request.text).then(sendResponse).catch(e => sendResponse({ error: e.message }));
      break;
    case 'getSummary':
      getSummary(request.text).then(sendResponse).catch(e => sendResponse({ error: e.message }));
      break;
    case 'getFactCheck':
      getFactCheck(request.text).then(sendResponse).catch(e => sendResponse({ error: e.message }));
      break;
    case 'getSettings':
      chrome.storage.local.get(null, sendResponse);
      break;
    case 'updateSettings':
      chrome.storage.local.set(request.settings, () => sendResponse({ success: true }));
      break;
  }
  return true;
});

async function analyzeText(text) {
  return await callGroq(`
Analyze the article below for bias.
Return ONLY JSON:
{
  "bias_score": 0.0 - 1.0,
  "bias_explanation": "...",
  "biased_phrases": [
    {
      "phrase": "...",
      "bias_type": "...",
      "neutral_alternative": "..."
    }
  ]
}
ARTICLE:
"""${text.slice(0, 3000)}"""`);
}

async function getSummary(text) {
  return await callGroq(`
Summarize the article in a neutral tone.
Return JSON: { "summary": "..." }
ARTICLE:
"""${text.slice(0, 3000)}"""`);
}

async function getFactCheck(text) {
  return await callGroq(`
Extract up to 3 factual claims and rate them.
Return ONLY JSON:
{
  "fact_checks": [
    {
      "claim": "...",
      "rating": "...",
      "explanation": "...",
      "source": "..."
    }
  ]
}
ARTICLE:
"""${text.slice(0, 3000)}"""`);
}

async function callGroq(prompt) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);

  try {
    const res = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        temperature: 0.2,
        messages: [
          { role: 'system', content: 'You are a neutral AI for bias detection, summarization, and fact-checking.' },
          { role: 'user', content: prompt }
        ]
      }),
      signal: controller.signal
    });

    clearTimeout(timeout);
    if (!res.ok) throw new Error(`GROQ API Error ${res.status}: ${await res.text()}`);
    const data = await res.json();
    const content = data.choices[0].message.content;

    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || content.match(/{[\s\S]*}/);
    if (!jsonMatch) throw new Error('Failed to extract JSON from model response: ' + content);
    return JSON.parse(jsonMatch[1] || jsonMatch[0]);

  } catch (err) {
    if (err.name === 'AbortError') throw new Error('Request timed out.');
    throw err;
  }
}

// -------------- JSON extraction helper -----------------
function extractJson(raw) {
  // 1. remove ``` fences and anything before first {
  let txt = raw.replace(/```[\s\S]*?```/g, m => m.replace(/```(?:json)?/i,'').replace(/```/,''))
               .trim();
  const firstBrace = txt.indexOf('{');
  if (firstBrace > 0) txt = txt.slice(firstBrace);

  // 2. normalise fancy quotes
  txt = txt.replace(/[“”]/g,'"').replace(/[‘’]/g,"'");

  // 3. drop trailing commas before } or ]
  txt = txt.replace(/,\s*([}\]])/g,'$1');

  // 4. try strict JSON
  try { return JSON.parse(txt); } catch(e) {/*ignore*/}

  // 5. fallback: JSON5 for comments / unquoted keys
  try {
    if (!window.JSON5) importScripts('https://cdnjs.cloudflare.com/ajax/libs/json5/2.2.3/index.min.js');
    return JSON5.parse(txt);
  } catch(err) {
    throw new Error('Failed to parse model JSON: ' + err.message + '\n-- Raw --\n' + txt);
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (tab.id) {
    chrome.tabs.sendMessage(tab.id, { action: 'toggleBiasBuster' });
  }
});
