# 🧠 Bias Buster - Chrome Extension for Media Bias Detection

**Bias Buster** is a powerful Chrome extension that detects bias in online media articles, rewrites biased phrases neutrally, summarizes articles objectively, and performs fact-checking using AI. Built using GROQ's LLaMA 3 model, Bias Buster promotes critical reading and enhances media literacy.

---

## 🔍 Features

- **Bias Detection**: Detects and highlights biased phrases in news articles.
- **Neutral Rewrites**: Suggests neutral alternatives for detected biased phrases.
- **Bias Score**: Assigns an overall bias score (0.0 - 1.0) to articles.
- **Objective Summary**: Generates a balanced summary of the article.
- **Fact Checking**: Extracts up to 3 factual claims and verifies them.
- **Custom Analyzer**: Allows users to paste any text (min. 50 words) for full analysis.
- **Floating UI**: A draggable, collapsible UI with a toggle icon (👁️‍🗨️) to view bias insights.
- **Interactive Visualizations**: See bias categories and word clouds for quick understanding.
- **User Preferences**: Enable/disable specific features from the popup UI.
- **Feedback Support**: Submit suggestions or report issues directly from the extension.

---

## 🧑‍💻 Tech Stack

| Layer         | Technologies Used                                       |
|---------------|----------------------------------------------------------|
| Extension API | Chrome Extensions API                                   |
| Backend AI    | [GROQ API](https://groq.com) with `llama3-70b-8192` model |
| Frontend UI   | HTML, CSS, JavaScript                                   |
| Libraries     | Bootstrap (popup), Native JS animations, JSON handling  |

---

## 🚀 How It Works

1. **On Page Load**:
   - Detects if the current page contains a news article.
   - Extracts text content from `<article>` or similar DOM elements.
   - Displays a floating button for analysis.

2. **On Click ("👁️‍🗨️")**:
   - Performs bias analysis, summary generation, and fact-checking using the GROQ API.
   - Visualizes results with bias meter, phrases list, summaries, and fact-checks.

3. **Custom Analyzer**:
   - Accessed from the popup.
   - Allows users to input any text for complete bias evaluation.

4. **Popup Interface**:
   - Toggle features on/off.
   - Analyze current page.
   - Open custom analyzer.
   - Submit feedback.

---

## 📦 Installation & Usage

### From Source (Dev Mode)
1. Clone or download this repository.
2. Go to `chrome://extensions/` in Chrome.
3. Enable **Developer Mode**.
4. Click **"Load unpacked"** and select the project folder.
5. Pin the extension and visit a news article to try it out!

---

## 📘 User Guide

- 🟢 **Enable Extension**: Use the popup to turn the extension on/off.
- 📝 **Analyze Page**: Click "Analyze This Page" in popup or use the floating icon.
- ✍️ **Custom Text**: Use "Open Custom Analyzer" for manual text input.
- ⚙️ **Settings**: Enable/disable highlights, summaries, rewrites, and more from the popup.
- 💬 **Feedback**: Submit issues or ideas directly from the extension interface.

---

## 🔐 Privacy & API Key
This extension uses a GROQ API key to call the `llama3-70b-8192` model for analysis. No user-identifiable data is stored or transmitted to any third-party servers beyond the GROQ API for processing.
---
## 🙌 Contributing
Want to improve Bias Buster? Fork the repo, add new features, or polish the UI and send in a PR!
---
## 📄 License
MIT License © 2025
---