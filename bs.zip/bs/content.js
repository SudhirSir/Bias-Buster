// Content script for Bias Buster extension
// Analyzes and modifies the webpage to show bias information

// Global variables to store analysis data
let biasAnalysis = null;
let articleSummary = null;
let factCheckResults = null;
let settings = {
  enabled: true,
  highlightBias: true,
  showNeutralRewrites: true,
  showBiasScore: true,
  showSummary: true,
  showFactChecking: true
};

// Initialize when the page loads
(function() {
  console.log('Bias Buster content script initialized');
  
  // Get extension settings
  chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
    if (response) {
      settings = response;
      if (settings.enabled) {
        initializeBiasBuster();
      }
    }
  });

  // Listen for messages from popup or background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'settingsUpdated') {
      chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
        settings = response;
        
        // Remove previous highlights if setting was turned off
        if (!settings.highlightBias) {
          removeHighlights();
        }
        
        // Re-analyze if extension is enabled
        if (settings.enabled) {
          initializeBiasBuster();
        } else {
          cleanup();
        }
        
        sendResponse({ success: true });
      });
      return true;
    } else if (request.action === 'forceBiasAnalysis') {
      // Force a new analysis when the user clicks "Analyze This Page"
      console.log('Force bias analysis requested');
      if (settings.enabled) {
        // Remove any existing UI and highlights
        cleanup();
        
        // Extract article text
        const articleText = extractArticleText();
        
        if (articleText) {
          // Create the floating dot toggle
          createFloatingDotToggle(articleText);
          
          sendResponse({ success: true });
        } else {
          console.error('No article text found to analyze');
          sendResponse({ error: 'No article text found to analyze' });
        }
      } else {
        console.error('Extension is disabled');
        sendResponse({ error: 'Extension is disabled' });
      }
      return true;
    } else if (request.action === 'toggleBiasBuster') {
      // Toggle the Bias Buster interface (keyboard shortcut)
      console.log('Toggle Bias Buster requested');
      if (settings.enabled) {
        const ui = document.getElementById('bias-buster-ui');
        const dot = document.getElementById('bias-buster-dot');
        
        if (ui) {
          // Toggle UI visibility if it exists
          if (ui.style.display === 'none') {
            ui.style.display = 'block';
          } else {
            ui.style.display = 'none';
          }
          sendResponse({ success: true });
        } else {
          // Create new UI if it doesn't exist
          const articleText = extractArticleText();
          if (articleText) {
            // If no dot exists, create it
            if (!dot) {
              createFloatingDotToggle(articleText);
            }
            // If dot exists but UI doesn't, simulate a click on the dot
            else if (dot) {
              dot.click();
            }
            sendResponse({ success: true });
          } else {
            console.error('No article text found to analyze');
            sendResponse({ error: 'No article text found to analyze' });
          }
        }
      } else {
        console.error('Extension is disabled');
        sendResponse({ error: 'Extension is disabled' });
      }
      return true;
    } else if (request.action === 'openCustomTextAnalyzer') {
      // Open the custom text analyzer
      console.log('Custom text analyzer requested');
      if (settings.enabled) {
        // Remove any existing UI and highlights
        cleanup();
        // Create custom text analyzer UI
        createCustomTextAnalyzer();
        sendResponse({ success: true });
      } else {
        console.error('Extension is disabled');
        sendResponse({ error: 'Extension is disabled' });
      }
      return true;
    }
  });
})();

// Initialize the main functionality
function initializeBiasBuster() {
  // Wait for the page to fully load
  setTimeout(() => {
    // Identify if we're on a news article page
    if (isNewsArticle()) {
      // Extract article text
      const articleText = extractArticleText();
      
      if (articleText) {
        // Create the floating dot toggle
        createFloatingDotToggle(articleText);
      }
    }
  }, 1500);
}

// Create floating dot toggle
function createFloatingDotToggle(articleText) {
  // Remove any existing UI elements
  const existingUI = document.getElementById('bias-buster-ui');
  if (existingUI) {
    existingUI.remove();
  }
  
  const existingDot = document.getElementById('bias-buster-dot');
  if (existingDot) {
    existingDot.remove();
  }
  
  // Create the floating dot
  const dot = document.createElement('div');
  dot.id = 'bias-buster-dot';
  dot.className = 'bias-buster-dot';
  dot.innerHTML = '⚙';
  dot.title = 'Click to open Bias Buster';
  
  // Style for the dot
  dot.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg,rgb(27, 27, 27),rgb(24, 24, 24));
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 9999;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    font-size: 24px;
  `;
  
  // Add hover effect
  dot.addEventListener('mouseover', () => {
    dot.style.transform = 'scale(1.1)';
    dot.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.4)';
  });
  
  dot.addEventListener('mouseout', () => {
    dot.style.transform = 'scale(1)';
    dot.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.3)';
  });
  
  // Add click event to toggle the full UI
  dot.addEventListener('click', () => {
    const existingFullUI = document.getElementById('bias-buster-ui');
    if (existingFullUI) {
      // If UI exists, toggle its visibility
      if (existingFullUI.style.display === 'none') {
        existingFullUI.style.display = 'block';
      } else {
        existingFullUI.style.display = 'none';
      }
    } else {
      // If UI doesn't exist, create it and analyze
      createFloatingUI();
      analyzeArticle(articleText);
    }
  });
  
  document.body.appendChild(dot);
}

// Check if current page is likely a news article
function isNewsArticle() {
  // Look for common indicators of news articles
  const hasArticleTag = document.querySelector('article') !== null;
  const hasNewsKeywords = document.querySelector('meta[property="og:type"][content="article"]') !== null;
  const hasLongParagraphs = document.querySelectorAll('p').length > 5;
  
  return hasArticleTag || hasNewsKeywords || hasLongParagraphs;
}

// Extract the main text content from the article
function extractArticleText() {
  let articleContent = '';
  
  // Try common article selectors
  const selectors = [
    'article',
    '.article-body',
    '.story-body',
    '.entry-content',
    '.post-content',
    '.article-content',
    '#content',
    '.content',
    'main'
  ];
  
  let articleElement = null;
  
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      articleElement = element;
      break;
    }
  }
  
  // If we found an article element, extract text from paragraphs
  if (articleElement) {
    const paragraphs = articleElement.querySelectorAll('p');
    for (const paragraph of paragraphs) {
      articleContent += paragraph.textContent + '\n\n';
    }
  } else {
    // Fallback: get all paragraphs in the document
    const paragraphs = document.querySelectorAll('p');
    for (const paragraph of paragraphs) {
      // Skip very short paragraphs that are likely not part of the article
      if (paragraph.textContent.trim().length > 40) {
        articleContent += paragraph.textContent + '\n\n';
      }
    }
  }
  
  return articleContent.trim();
}

// Analyze the article for bias
function analyzeArticle(text) {
  showLoadingIndicator();
  
  // Send text to background script for analysis
  chrome.runtime.sendMessage({ 
    action: 'analyzeText', 
    text: text 
  }, (response) => {
    hideLoadingIndicator();
    
    if (response && !response.error) {
      biasAnalysis = response;
      updateBiasDisplay();
      
      if (settings.highlightBias) {
        highlightBiasedText(biasAnalysis.biased_phrases);
      }
      
      // Get article summary if enabled
      if (settings.showSummary) {
        chrome.runtime.sendMessage({ 
          action: 'getSummary', 
          text: text 
        }, (summaryResponse) => {
          if (summaryResponse && !summaryResponse.error) {
            articleSummary = summaryResponse;
            updateSummaryDisplay();
          }
        });
      }
      
      // Get fact checking if enabled
      if (settings.showFactChecking) {
        chrome.runtime.sendMessage({ 
          action: 'getFactCheck', 
          text: text 
        }, (factCheckResponse) => {
          if (factCheckResponse && !factCheckResponse.error) {
            factCheckResults = factCheckResponse;
            updateFactCheckDisplay();
          }
        });
      }
    } else {
      showError(response?.error || 'Failed to analyze text');
    }
  });
}

// Create floating UI for displaying bias information
function createFloatingUI() {
  // Remove any existing UI
  const existingUI = document.getElementById('bias-buster-ui');
  if (existingUI) {
    existingUI.remove();
  }
  
  // Create the main container
  const container = document.createElement('div');
  container.id = 'bias-buster-ui';
  container.className = 'bias-buster-container';
  
  // Create header
  const header = document.createElement('div');
  header.className = 'bias-buster-header';
  header.innerHTML = `
    <div class="bias-buster-logo">
      <span class="icon">⚙</span> Bias Buster
    </div>
    <div class="bias-buster-controls">
      <button id="bias-buster-minimize" class="bias-buster-btn">_</button>
      <button id="bias-buster-close" class="bias-buster-btn">×</button>
    </div>
  `;
  
  // Create content area
  const content = document.createElement('div');
  content.className = 'bias-buster-content';
  
  // Create sections
  const scoreSection = document.createElement('div');
  scoreSection.id = 'bias-buster-score-section';
  scoreSection.className = 'bias-buster-section';
  scoreSection.innerHTML = '<h3>Bias Analysis</h3><div id="bias-buster-score-content"><div class="bias-buster-loading">Analyzing...</div></div>';
  
  const phrasesSection = document.createElement('div');
  phrasesSection.id = 'bias-buster-phrases-section';
  phrasesSection.className = 'bias-buster-section';
  phrasesSection.innerHTML = '<h3>Biased Phrases</h3><div id="bias-buster-phrases-content"></div>';
  
  const summarySection = document.createElement('div');
  summarySection.id = 'bias-buster-summary-section';
  summarySection.className = 'bias-buster-section';
  summarySection.innerHTML = '<h3>Objective Summary</h3><div id="bias-buster-summary-content"><div class="bias-buster-loading">Generating summary...</div></div>';
  
  const factCheckSection = document.createElement('div');
  factCheckSection.id = 'bias-buster-factcheck-section';
  factCheckSection.className = 'bias-buster-section';
  factCheckSection.innerHTML = '<h3>Fact Checking</h3><div id="bias-buster-factcheck-content"><div class="bias-buster-loading">Checking facts...</div></div>';
  
  // Add sections to content
  if (settings.showBiasScore) {
    content.appendChild(scoreSection);
  }
  content.appendChild(phrasesSection);
  if (settings.showSummary) {
    content.appendChild(summarySection);
  }
  if (settings.showFactChecking) {
    content.appendChild(factCheckSection);
  }
  
  // Add header and content to container
  container.appendChild(header);
  container.appendChild(content);
  
  // Add container to document
  document.body.appendChild(container);
  
  // Add event listeners
  document.getElementById('bias-buster-minimize').addEventListener('click', toggleMinimize);
  document.getElementById('bias-buster-close').addEventListener('click', () => {
    container.remove();
  });
  
  // Make the UI draggable
  makeElementDraggable(container, header);
}

// Make an element draggable
function makeElementDraggable(element, handle) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  
  handle.onmousedown = dragMouseDown;
  
  function dragMouseDown(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }
  
  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    element.style.top = (element.offsetTop - pos2) + "px";
    element.style.left = (element.offsetLeft - pos1) + "px";
  }
  
  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

// Toggle minimize/maximize the floating UI
function toggleMinimize() {
  const content = document.querySelector('.bias-buster-content');
  if (content.style.display === 'none') {
    content.style.display = 'block';
    document.getElementById('bias-buster-minimize').textContent = '_';
  } else {
    content.style.display = 'none';
    document.getElementById('bias-buster-minimize').textContent = '□';
  }
}

// Update the bias score display
function updateBiasDisplay() {
  const scoreContent = document.getElementById('bias-buster-score-content');
  if (!scoreContent) return;
  
  // Display bias score
  const score = biasAnalysis.bias_score;
  let scoreClass = 'neutral';
  let scoreLabel = 'Neutral';
  
  if (score <= 0.2) {
    scoreClass = 'very-low';
    scoreLabel = 'Very Low Bias';
  } else if (score <= 0.4) {
    scoreClass = 'low';
    scoreLabel = 'Low Bias';
  } else if (score <= 0.6) {
    scoreClass = 'medium';
    scoreLabel = 'Medium Bias';
  } else if (score <= 0.8) {
    scoreClass = 'high';
    scoreLabel = 'High Bias';
  } else {
    scoreClass = 'very-high';
    scoreLabel = 'Very High Bias';
  }
  
  scoreContent.innerHTML = `
    <div class="bias-score-container">
      <div class="bias-meter">
        <div class="bias-meter-bar">
          <div class="bias-meter-fill bias-${scoreClass}" style="width: ${score * 100}%"></div>
        </div>
        <div class="bias-meter-label">${scoreLabel} (${Math.round(score * 100)}%)</div>
      </div>
      <div class="bias-details">
        <p>${biasAnalysis.bias_explanation}</p>
      </div>
    </div>
  `;
  
  // Display biased phrases
  const phrasesContent = document.getElementById('bias-buster-phrases-content');
  if (phrasesContent) {
    if (biasAnalysis.biased_phrases && biasAnalysis.biased_phrases.length > 0) {
      let phrasesHtml = '<ul class="biased-phrases-list">';
      
      biasAnalysis.biased_phrases.forEach(phrase => {
        phrasesHtml += `
          <li class="biased-phrase-item">
            <div class="biased-text">${phrase.phrase}</div>
            <div class="bias-type">${phrase.bias_type}</div>
            ${settings.showNeutralRewrites ? `<div class="neutral-rewrite">Neutral alternative: "${phrase.neutral_alternative}"</div>` : ''}
          </li>
        `;
      });
      
      phrasesHtml += '</ul>';
      phrasesContent.innerHTML = phrasesHtml;
    } else {
      phrasesContent.innerHTML = '<p class="no-bias-message">No significantly biased phrases detected.</p>';
    }
  }
}

// Update the summary display
function updateSummaryDisplay() {
  const summaryContent = document.getElementById('bias-buster-summary-content');
  if (!summaryContent) return;
  
  if (articleSummary && articleSummary.summary) {
    summaryContent.innerHTML = `<p>${articleSummary.summary}</p>`;
  } else {
    summaryContent.innerHTML = '<p class="error-message">Unable to generate summary.</p>';
  }
}

// Update the fact checking display
function updateFactCheckDisplay() {
  const factCheckContent = document.getElementById('bias-buster-factcheck-content');
  if (!factCheckContent) return;
  
  if (factCheckResults && factCheckResults.fact_checks && factCheckResults.fact_checks.length > 0) {
    let factChecksHtml = '<ul class="fact-check-list">';
    
    factCheckResults.fact_checks.forEach(factCheck => {
      let ratingClass = '';
      
      switch (factCheck.rating.toLowerCase()) {
        case 'true':
        case 'mostly true':
          ratingClass = 'true';
          break;
        case 'half true':
        case 'mixed':
          ratingClass = 'mixed';
          break;
        case 'mostly false':
        case 'false':
        case 'pants on fire':
          ratingClass = 'false';
          break;
        default:
          ratingClass = 'unknown';
      }
      
      factChecksHtml += `
        <li class="fact-check-item">
          <div class="claim">${factCheck.claim}</div>
          <div class="rating rating-${ratingClass}">${factCheck.rating}</div>
          <div class="source">Source: ${factCheck.source}</div>
          ${factCheck.explanation ? `<div class="explanation">${factCheck.explanation}</div>` : ''}
        </li>
      `;
    });
    
    factChecksHtml += '</ul>';
    factCheckContent.innerHTML = factChecksHtml;
  } else {
    factCheckContent.innerHTML = '<p>No fact checks available for this article.</p>';
  }
}

// Highlight biased text in the article
function highlightBiasedText(biasedPhrases) {
  if (!biasedPhrases || biasedPhrases.length === 0) return;
  
  // Collect all text nodes in the document
  const textNodes = [];
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: function(node) {
        // Skip nodes in our UI and script tags
        if (isDescendantOf(node, document.getElementById('bias-buster-ui'))) {
          return NodeFilter.FILTER_REJECT;
        }
        if (node.parentNode.tagName === 'SCRIPT' || 
            node.parentNode.tagName === 'STYLE' || 
            node.parentNode.tagName === 'NOSCRIPT') {
          return NodeFilter.FILTER_REJECT;
        }
        // Skip empty nodes or nodes with just whitespace
        if (node.textContent.trim() === '') {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    },
    false
  );
  
  let currentNode;
  while (currentNode = walker.nextNode()) {
    textNodes.push(currentNode);
  }
  
  // Highlight each biased phrase in text nodes
  biasedPhrases.forEach(phrase => {
    const biasedText = phrase.phrase;
    const biasType = phrase.bias_type;
    const neutralAlt = phrase.neutral_alternative;
    
    for (const node of textNodes) {
      const text = node.textContent;
      if (text.includes(biasedText)) {
        // Split the text node and highlight the biased part
        const parts = text.split(biasedText);
        
        if (parts.length > 1) {
          const fragment = document.createDocumentFragment();
          
          for (let i = 0; i < parts.length; i++) {
            // Add the text before the match
            if (parts[i]) {
              fragment.appendChild(document.createTextNode(parts[i]));
            }
            
            // Add the highlighted text (except after the last part)
            if (i < parts.length - 1) {
              const span = document.createElement('span');
              span.className = 'bias-buster-highlight';
              span.textContent = biasedText;
              span.setAttribute('data-bias-type', biasType);
              span.setAttribute('data-neutral-alt', neutralAlt);
              
              // Add tooltip functionality
              span.addEventListener('mouseover', function(e) {
                showTooltip(this, e);
              });
              span.addEventListener('mouseout', function() {
                hideTooltip();
              });
              
              fragment.appendChild(span);
            }
          }
          
          // Replace the original node with our fragment
          node.parentNode.replaceChild(fragment, node);
        }
      }
    }
  });
}

// Show tooltip with neutral alternative
function showTooltip(element, event) {
  // Remove any existing tooltips
  hideTooltip();
  
  const biasType = element.getAttribute('data-bias-type');
  const neutralAlt = element.getAttribute('data-neutral-alt');
  
  const tooltip = document.createElement('div');
  tooltip.className = 'bias-buster-tooltip';
  tooltip.innerHTML = `
    <div class="tooltip-bias-type">${biasType} bias detected</div>
    <div class="tooltip-neutral">Neutral alternative: "${neutralAlt}"</div>
  `;
  
  // Position the tooltip
  const rect = element.getBoundingClientRect();
  tooltip.style.left = `${rect.left + window.scrollX}px`;
  tooltip.style.top = `${rect.bottom + window.scrollY + 5}px`;
  
  document.body.appendChild(tooltip);
}

// Hide tooltip
function hideTooltip() {
  const tooltip = document.querySelector('.bias-buster-tooltip');
  if (tooltip) {
    tooltip.remove();
  }
}

// Check if node is descendant of an element
function isDescendantOf(node, ancestor) {
  let parent = node.parentNode;
  while (parent) {
    if (parent === ancestor) {
      return true;
    }
    parent = parent.parentNode;
  }
  return false;
}

// Remove all highlights from the page
function removeHighlights() {
  const highlights = document.querySelectorAll('.bias-buster-highlight');
  
  highlights.forEach(highlight => {
    const text = highlight.textContent;
    const textNode = document.createTextNode(text);
    highlight.parentNode.replaceChild(textNode, highlight);
  });
}

// Show loading indicator
function showLoadingIndicator() {
  const uiContainer = document.getElementById('bias-buster-ui');
  if (!uiContainer) return;
  
  const loading = document.createElement('div');
  loading.className = 'bias-buster-loading-overlay';
  loading.innerHTML = '<div class="bias-buster-spinner"></div><div>Analyzing article...</div>';
  
  uiContainer.appendChild(loading);
}

// Hide loading indicator
function hideLoadingIndicator() {
  const loading = document.querySelector('.bias-buster-loading-overlay');
  if (loading) {
    loading.remove();
  }
}

// Show error message
function showError(message) {
  const scoreContent = document.getElementById('bias-buster-score-content');
  const phrasesContent = document.getElementById('bias-buster-phrases-content');
  
  if (scoreContent) {
    scoreContent.innerHTML = `<p class="error-message">${message}</p>`;
  }
  
  if (phrasesContent) {
    phrasesContent.innerHTML = '';
  }
}

// Clean up UI elements
// Create custom text analyzer UI
function createCustomTextAnalyzer() {
  // Remove any existing UI
  const existingUI = document.getElementById('bias-buster-ui');
  if (existingUI) {
    existingUI.remove();
  }
  
  // Create the main container
  const container = document.createElement('div');
  container.id = 'bias-buster-ui';
  container.className = 'bias-buster-container custom-analyzer';
  
  // Create header
  const header = document.createElement('div');
  header.className = 'bias-buster-header';
  header.innerHTML = `
    <div class="bias-buster-logo">
      <span class="icon">⚙</span> Custom Text Analyzer
    </div>
    <div class="bias-buster-controls">
      <button id="bias-buster-minimize" class="bias-buster-btn">_</button>
      <button id="bias-buster-close" class="bias-buster-btn">×</button>
    </div>
  `;
  
  // Create content area
  const content = document.createElement('div');
  content.className = 'bias-buster-content';
  
  // Create custom text input section
  const inputSection = document.createElement('div');
  inputSection.className = 'bias-buster-section';
  inputSection.innerHTML = `
    <h3>Analyze Custom Text</h3>
    <p class="custom-text-instructions">Enter text (minimum 50 words) to check for bias, get an objective summary, and verify facts.</p>
    <div class="custom-text-container">
      <textarea id="custom-text-input" class="custom-text-area" 
        placeholder=" Paste or type your text here (minimum 50 words)..."
        rows="8"></textarea>
      <div class="word-counter">0 words</div>
      <div class="custom-text-actions">
        <button id="analyze-custom-text" class="btn btn-primary">
          <span class="btn-icon">⚡</span> Analyze Text
        </button>
        <button id="clear-custom-text" class="btn btn-secondary">
          <span class="btn-icon">✕</span> Clear
        </button>
      </div>
    </div>
  `;
  
  // Create tabs for results
  const tabsSection = document.createElement('div');
  tabsSection.className = 'bias-buster-section tabs-section';
  tabsSection.style.display = 'none'; // Initially hidden
  tabsSection.innerHTML = `
    <div class="tabs-container">
      <div class="tabs-header">
        <button class="tab-btn active" data-tab="bias">Bias Analysis</button>
        <button class="tab-btn" data-tab="summary">Summary</button>
        <button class="tab-btn" data-tab="factcheck">Fact Check</button>
        <button class="tab-btn" data-tab="visualization">Visualization</button>
      </div>
      <div class="tabs-content">
        <div id="tab-bias" class="tab-content active">
          <div id="custom-bias-content">
            <div class="placeholder-text">Analyze text to see bias results</div>
          </div>
        </div>
        <div id="tab-summary" class="tab-content">
          <div id="custom-summary-content">
            <div class="placeholder-text">Analyze text to see summary</div>
          </div>
        </div>
        <div id="tab-factcheck" class="tab-content">
          <div id="custom-factcheck-content">
            <div class="placeholder-text">Analyze text to see fact checks</div>
          </div>
        </div>
        <div id="tab-visualization" class="tab-content">
          <div id="custom-visualization-content">
            <div class="placeholder-text">Analyze text to see visualizations</div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Add sections to content
  content.appendChild(inputSection);
  content.appendChild(tabsSection);
  
  // Add header and content to container
  container.appendChild(header);
  container.appendChild(content);
  
  // Add container to document
  document.body.appendChild(container);
  
  // Add event listeners
  document.getElementById('bias-buster-minimize').addEventListener('click', toggleMinimize);
  document.getElementById('bias-buster-close').addEventListener('click', () => {
    container.remove();
  });
  
  // Make the UI draggable
  makeElementDraggable(container, header);
  
  // Add word counter functionality
  const textarea = document.getElementById('custom-text-input');
  const wordCounter = document.querySelector('.word-counter');
  
  textarea.addEventListener('input', () => {
    const text = textarea.value.trim();
    const wordCount = text ? text.split(/\s+/).length : 0;
    wordCounter.textContent = `${wordCount} words`;
    
    // Enable/disable analyze button based on word count
    const analyzeBtn = document.getElementById('analyze-custom-text');
    if (wordCount >= 50) {
      analyzeBtn.disabled = false;
      wordCounter.classList.remove('text-danger');
      wordCounter.classList.add('text-success');
    } else {
      analyzeBtn.disabled = true;
      wordCounter.classList.remove('text-success');
      wordCounter.classList.add('text-danger');
    }
  });
  
  // Add tab switching functionality
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Remove active class from all buttons and content
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      
      // Add active class to current button and content
      btn.classList.add('active');
      const tabId = `tab-${btn.dataset.tab}`;
      document.getElementById(tabId).classList.add('active');
    });
  });
  
  // Add analyze button functionality
  document.getElementById('analyze-custom-text').addEventListener('click', () => {
    const text = textarea.value.trim();
    if (text.split(/\s+/).length >= 50) {
      analyzeCustomText(text);
      // Show the tabs section
      tabsSection.style.display = 'block';
      // Scroll to the tabs
      tabsSection.scrollIntoView({ behavior: 'smooth' });
    }
  });
  
  // Add clear button functionality
  document.getElementById('clear-custom-text').addEventListener('click', () => {
    textarea.value = '';
    wordCounter.textContent = '0 words';
    document.getElementById('analyze-custom-text').disabled = true;
    tabsSection.style.display = 'none';
    
    // Reset all content sections
    document.getElementById('custom-bias-content').innerHTML = '<div class="placeholder-text">Analyze text to see bias results</div>';
    document.getElementById('custom-summary-content').innerHTML = '<div class="placeholder-text">Analyze text to see summary</div>';
    document.getElementById('custom-factcheck-content').innerHTML = '<div class="placeholder-text">Analyze text to see fact checks</div>';
    document.getElementById('custom-visualization-content').innerHTML = '<div class="placeholder-text">Analyze text to see visualizations</div>';
  });
}

// Analyze custom text
function analyzeCustomText(text) {
  // Update all content sections with loading indicators
  document.getElementById('custom-bias-content').innerHTML = '<div class="bias-buster-loading">Analyzing bias...</div>';
  document.getElementById('custom-summary-content').innerHTML = '<div class="bias-buster-loading">Generating summary...</div>';
  document.getElementById('custom-factcheck-content').innerHTML = '<div class="bias-buster-loading">Checking facts...</div>';
  document.getElementById('custom-visualization-content').innerHTML = '<div class="bias-buster-loading">Generating visualizations...</div>';
  
  // Send text to background script for analysis
  chrome.runtime.sendMessage({ 
    action: 'analyzeText', 
    text: text 
  }, (response) => {
    if (response && !response.error) {
      // Update bias analysis tab
      updateCustomBiasDisplay(response);
      
      // Create visualization
      createBiasVisualization(response);
    } else {
      document.getElementById('custom-bias-content').innerHTML = '<p class="error-message">Failed to analyze bias.</p>';
      document.getElementById('custom-visualization-content').innerHTML = '<p class="error-message">Failed to generate visualizations.</p>';
    }
  });
  
  // Get summary
  chrome.runtime.sendMessage({ 
    action: 'getSummary', 
    text: text 
  }, (response) => {
    if (response && !response.error) {
      updateCustomSummaryDisplay(response);
    } else {
      document.getElementById('custom-summary-content').innerHTML = '<p class="error-message">Failed to generate summary.</p>';
    }
  });
  
  // Get fact checking
  chrome.runtime.sendMessage({ 
    action: 'getFactCheck', 
    text: text 
  }, (response) => {
    if (response && !response.error) {
      updateCustomFactCheckDisplay(response);
    } else {
      document.getElementById('custom-factcheck-content').innerHTML = '<p class="error-message">Failed to check facts.</p>';
    }
  });
}

// Update custom bias display
function updateCustomBiasDisplay(analysis) {
  const biasContent = document.getElementById('custom-bias-content');
  if (!biasContent) return;
  
  // Display bias score
  const score = analysis.bias_score;
  let scoreClass = 'neutral';
  let scoreLabel = 'Neutral';
  
  if (score <= 0.2) {
    scoreClass = 'very-low';
    scoreLabel = 'Very Low Bias';
  } else if (score <= 0.4) {
    scoreClass = 'low';
    scoreLabel = 'Low Bias';
  } else if (score <= 0.6) {
    scoreClass = 'medium';
    scoreLabel = 'Medium Bias';
  } else if (score <= 0.8) {
    scoreClass = 'high';
    scoreLabel = 'High Bias';
  } else {
    scoreClass = 'very-high';
    scoreLabel = 'Very High Bias';
  }
  
  let biasHtml = `
    <div class="bias-score-container">
      <div class="bias-meter">
        <div class="bias-meter-bar">
          <div class="bias-meter-fill bias-${scoreClass}" style="width: ${score * 100}%"></div>
        </div>
        <div class="bias-meter-label">${scoreLabel} (${Math.round(score * 100)}%)</div>
      </div>
      <div class="bias-details">
        <p>${analysis.bias_explanation}</p>
      </div>
    </div>
  `;
  
  // Display biased phrases
  if (analysis.biased_phrases && analysis.biased_phrases.length > 0) {
    biasHtml += '<h4>Biased Phrases</h4><ul class="biased-phrases-list">';
    
    analysis.biased_phrases.forEach(phrase => {
      biasHtml += `
        <li class="biased-phrase-item">
          <div class="biased-text">${phrase.phrase}</div>
          <div class="bias-type">${phrase.bias_type}</div>
          <div class="neutral-rewrite">Neutral alternative: "${phrase.neutral_alternative}"</div>
        </li>
      `;
    });
    
    biasHtml += '</ul>';
  } else {
    biasHtml += '<p class="no-bias-message">No significantly biased phrases detected.</p>';
  }
  
  biasContent.innerHTML = biasHtml;
}

// Update custom summary display
function updateCustomSummaryDisplay(summary) {
  const summaryContent = document.getElementById('custom-summary-content');
  if (!summaryContent) return;
  
  if (summary && summary.summary) {
    summaryContent.innerHTML = `
      <div class="summary-container">
        <h4>Objective Summary</h4>
        <p class="summary-text">${summary.summary}</p>
      </div>
    `;
  } else {
    summaryContent.innerHTML = '<p class="error-message">Unable to generate summary.</p>';
  }
}

// Update custom fact check display
function updateCustomFactCheckDisplay(factChecks) {
  const factCheckContent = document.getElementById('custom-factcheck-content');
  if (!factCheckContent) return;
  
  if (factChecks && factChecks.fact_checks && factChecks.fact_checks.length > 0) {
    let factChecksHtml = '<h4>Fact Check Results</h4><ul class="fact-check-list">';
    
    factChecks.fact_checks.forEach(factCheck => {
      let ratingClass = '';
      
      switch (factCheck.rating.toLowerCase()) {
        case 'true':
        case 'mostly true':
          ratingClass = 'true';
          break;
        case 'half true':
        case 'mixed':
          ratingClass = 'mixed';
          break;
        case 'mostly false':
        case 'false':
        case 'pants on fire':
          ratingClass = 'false';
          break;
        default:
          ratingClass = 'unknown';
      }
      
      factChecksHtml += `
        <li class="fact-check-item">
          <div class="claim">${factCheck.claim}</div>
          <div class="rating rating-${ratingClass}">${factCheck.rating}</div>
          <div class="source">Source: ${factCheck.source}</div>
          ${factCheck.explanation ? `<div class="explanation">${factCheck.explanation}</div>` : ''}
        </li>
      `;
    });
    
    factChecksHtml += '</ul>';
    factCheckContent.innerHTML = factChecksHtml;
  } else {
    factCheckContent.innerHTML = '<p>No fact checks available for this text.</p>';
  }
}

// Create visualization of bias analysis
function createBiasVisualization(analysis) {
  const visualizationContent = document.getElementById('custom-visualization-content');
  if (!visualizationContent) return;
  
  // Create categories visualization
  let categoryData = {};
  
  if (analysis.biased_phrases && analysis.biased_phrases.length > 0) {
    analysis.biased_phrases.forEach(phrase => {
      const biasType = phrase.bias_type;
      if (categoryData[biasType]) {
        categoryData[biasType]++;
      } else {
        categoryData[biasType] = 1;
      }
    });
    
    let categoriesHtml = `
      <div class="visualization-container">
        <h4>Bias Categories</h4>
        <div class="bias-categories-chart">
    `;
    
    // Generate bar chart
    const maxCount = Math.max(...Object.values(categoryData));
    
    Object.keys(categoryData).forEach(category => {
      const count = categoryData[category];
      const percentage = Math.round((count / maxCount) * 100);
      
      categoriesHtml += `
        <div class="chart-row">
          <div class="chart-label">${category}</div>
          <div class="chart-bar-container">
            <div class="chart-bar" style="width: ${percentage}%">
              <span class="chart-value">${count}</span>
            </div>
          </div>
        </div>
      `;
    });
    
    categoriesHtml += `
        </div>
      </div>
    `;
    
    // Word cloud simulation for biased terms
    let phrasesHtml = `
      <div class="visualization-container">
        <h4>Biased Terms</h4>
        <div class="word-cloud">
    `;
    
    const phrases = analysis.biased_phrases.map(p => p.phrase);
    const uniquePhrases = [...new Set(phrases)];
    
    uniquePhrases.forEach(phrase => {
      // Calculate how many times this phrase appears
      const count = phrases.filter(p => p === phrase).length;
      const size = 1 + (count / phrases.length) * 1.5; // Scale factor for font size
      const rotation = Math.floor(Math.random() * 3 - 1) * 15; // Random rotation between -15, 0, and 15 degrees
      
      phrasesHtml += `
        <span class="cloud-word" style="font-size: ${size}em; transform: rotate(${rotation}deg);">
          ${phrase}
        </span>
      `;
    });
    
    phrasesHtml += `
        </div>
      </div>
    `;
    
    visualizationContent.innerHTML = categoriesHtml + phrasesHtml;
  } else {
    visualizationContent.innerHTML = `
      <div class="visualization-container">
        <p class="no-bias-message">No biased phrases detected to visualize.</p>
        <div class="bias-score-display">
          <h4>Bias Score</h4>
          <div class="bias-meter big">
            <div class="bias-meter-bar">
              <div class="bias-meter-fill bias-very-low" style="width: ${analysis.bias_score * 100}%"></div>
            </div>
            <div class="bias-meter-label">
              ${Math.round(analysis.bias_score * 100)}% Bias Score
            </div>
          </div>
        </div>
      </div>
    `;
  }
}

function cleanup() {
  const ui = document.getElementById('bias-buster-ui');
  if (ui) {
    ui.remove();
  }
  
  removeHighlights();
  
  const tooltip = document.querySelector('.bias-buster-tooltip');
  if (tooltip) {
    tooltip.remove();
  }
  
  const customTextUI = document.querySelector('.custom-analyzer');
  if (customTextUI) {
    customTextUI.remove();
  }
}

chrome.runtime.onMessage.addListener((req) => {
  if (req.action === 'toggleOverlay') {
    const existing = document.getElementById('bias-buster-overlay');
    if (existing) {
      existing.classList.toggle('visible');
      return;
    }
  
    else if (request.action === 'getCurrentBiasScore') {
  sendResponse({ bias_score: biasAnalysis?.bias_score ?? null });
  return true;
}

    fetch(chrome.runtime.getURL('overlay.html'))
      .then(res => res.text())
      .then(html => {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = html;
        document.body.appendChild(wrapper);

        setTimeout(() => {
          const overlay = document.getElementById('bias-buster-overlay');
          if (overlay) overlay.classList.add('visible');
        }, 50);
      });
  }
});